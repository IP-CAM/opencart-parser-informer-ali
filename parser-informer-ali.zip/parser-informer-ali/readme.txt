Need a vqmod

Download folders catalog and vqmod into the root of your website
Reload your main page
demo http://www.ali.nsk-seo24.ru/ 
Enjoy! 